package project.akbaralzaini.sesi2;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    TextView txtNama,txtJeniskelamin, txtAlamat;
    String nama, jeniskelamin, alamat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("stvsyc");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txtNama = findViewById(R.id.txtNama);
        txtJeniskelamin = findViewById(R.id.txtJeniskelamin);
        txtAlamat = findViewById(R.id.txtAlamat);

        Intent main = getIntent();
        Bundle bundle = main.getExtras();
        if (bundle !=  null){
            txtNama.setText(main.getExtras().getString("nama"));
            txtJeniskelamin.setText(main.getExtras().getString("jeniskelamin"));
            txtAlamat.setText(main.getExtras().getString("alamat"));
        }

    }
}